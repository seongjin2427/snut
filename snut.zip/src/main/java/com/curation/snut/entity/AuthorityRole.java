package com.curation.snut.entity;

public enum AuthorityRole {
  GUEST, MEMBER, ADMIN
}
