package com.curation.snut.entity;

public class Collection extends BaseEntity {

}
// collection

// curation을 list로(image)
// 누르면 read로보내기
// 좋아요도구현
// 만든사람 useremail로
// 닉네임도 email로
// 공개여부 01