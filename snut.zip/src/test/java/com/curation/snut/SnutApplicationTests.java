package com.curation.snut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnutApplicationTests {

    @Test
    void contextLoads() {
    }

}
